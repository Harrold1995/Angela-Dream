CREATE TABLE `jrg_brb_review` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `business_id` bigint(20) unsigned NOT NULL,  `review_id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `rating` int(11) NOT NULL,  `text` varchar(10000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `time` int(11) NOT NULL,  `time_str` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `language` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `author_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `author_url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `author_img` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `platform` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `brb_review_business_id` (`business_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_brb_review` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_brb_review` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
