CREATE TABLE `jrg_wdr_order_discounts` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `order_id` int(11) DEFAULT NULL,  `has_free_shipping` enum('yes','no') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'no',  `discounts` text COLLATE utf8mb4_unicode_520_ci NOT NULL,  `created_at` datetime DEFAULT NULL,  `updated_at` datetime DEFAULT NULL,  `extra` longtext COLLATE utf8mb4_unicode_520_ci,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_wdr_order_discounts` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_wdr_order_discounts` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
