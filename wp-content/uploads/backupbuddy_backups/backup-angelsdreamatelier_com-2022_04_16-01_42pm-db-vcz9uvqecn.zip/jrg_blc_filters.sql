CREATE TABLE `jrg_blc_filters` (  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `params` text COLLATE utf8mb4_unicode_520_ci NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_blc_filters` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_blc_filters` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
