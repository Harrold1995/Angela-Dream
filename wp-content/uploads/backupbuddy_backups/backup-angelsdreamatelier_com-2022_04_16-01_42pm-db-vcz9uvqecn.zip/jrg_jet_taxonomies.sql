CREATE TABLE `jrg_jet_taxonomies` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `slug` text COLLATE utf8mb4_unicode_520_ci,  `object_type` text COLLATE utf8mb4_unicode_520_ci,  `status` text COLLATE utf8mb4_unicode_520_ci,  `labels` longtext COLLATE utf8mb4_unicode_520_ci,  `args` longtext COLLATE utf8mb4_unicode_520_ci,  `meta_fields` longtext COLLATE utf8mb4_unicode_520_ci,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_jet_taxonomies` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_jet_taxonomies` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
