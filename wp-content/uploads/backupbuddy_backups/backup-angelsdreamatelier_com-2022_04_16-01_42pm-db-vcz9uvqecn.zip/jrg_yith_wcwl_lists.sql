CREATE TABLE `jrg_yith_wcwl_lists` (  `ID` int(11) NOT NULL AUTO_INCREMENT,  `user_id` int(11) DEFAULT NULL,  `wishlist_slug` varchar(200) NOT NULL,  `wishlist_name` text,  `wishlist_token` varchar(64) NOT NULL,  `wishlist_privacy` tinyint(1) NOT NULL DEFAULT '0',  `is_default` tinyint(1) NOT NULL DEFAULT '0',  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `session_id` varchar(255) DEFAULT NULL,  `expiration` timestamp NULL DEFAULT NULL,  PRIMARY KEY (`ID`),  UNIQUE KEY `wishlist_token` (`wishlist_token`),  UNIQUE KEY `wishlist_token_2` (`wishlist_token`),  KEY `wishlist_slug` (`wishlist_slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `jrg_yith_wcwl_lists` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_yith_wcwl_lists` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
