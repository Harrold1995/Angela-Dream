CREATE TABLE `jrg_brb_business` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `place_id` varchar(127) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `photo` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `icon` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `address` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `rating` double DEFAULT NULL,  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `website` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `review_count` int(11) DEFAULT NULL,  `platform` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `updated` bigint(20) DEFAULT NULL,  PRIMARY KEY (`id`),  UNIQUE KEY `brb_business_place_id` (`place_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_brb_business` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_brb_business` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
