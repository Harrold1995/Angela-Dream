CREATE TABLE `jrg_defender_scan` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `percent` float NOT NULL,  `total_tasks` tinyint(4) NOT NULL,  `task_checkpoint` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `date_start` datetime NOT NULL,  `date_end` datetime NOT NULL,  `is_automation` tinyint(1) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_defender_scan` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `jrg_defender_scan` VALUES('7', '100', '4', '', 'finish', '2022-04-10 08:36:17', '2022-04-10 09:51:02', '1');
/*!40000 ALTER TABLE `jrg_defender_scan` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
