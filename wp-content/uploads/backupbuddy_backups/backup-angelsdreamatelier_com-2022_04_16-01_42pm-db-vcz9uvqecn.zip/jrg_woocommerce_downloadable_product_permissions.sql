CREATE TABLE `jrg_woocommerce_downloadable_product_permissions` (  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `product_id` bigint(20) unsigned NOT NULL,  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `user_id` bigint(20) unsigned DEFAULT NULL,  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `access_expires` datetime DEFAULT NULL,  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`permission_id`),  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),  KEY `order_id` (`order_id`),  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_woocommerce_downloadable_product_permissions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_woocommerce_downloadable_product_permissions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
