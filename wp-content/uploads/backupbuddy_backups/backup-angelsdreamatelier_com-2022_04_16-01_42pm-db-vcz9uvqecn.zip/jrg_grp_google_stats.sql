CREATE TABLE `jrg_grp_google_stats` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `google_place_id` bigint(20) unsigned NOT NULL,  `time` int(11) NOT NULL,  `rating` double DEFAULT NULL,  `review_count` int(11) DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `grp_google_place_id` (`google_place_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_grp_google_stats` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_grp_google_stats` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
