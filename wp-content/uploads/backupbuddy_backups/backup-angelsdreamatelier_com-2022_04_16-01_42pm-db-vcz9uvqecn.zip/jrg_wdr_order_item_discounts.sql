CREATE TABLE `jrg_wdr_order_item_discounts` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `order_id` int(11) DEFAULT NULL,  `rule_id` int(11) DEFAULT NULL,  `item_id` int(11) DEFAULT NULL,  `item_price` float NOT NULL,  `discounted_price` float NOT NULL,  `discount` float NOT NULL,  `quantity` int(11) NOT NULL,  `simple_discount` float NOT NULL,  `bulk_discount` float NOT NULL,  `set_discount` float NOT NULL,  `cart_discount` float NOT NULL,  `has_free_shipping` enum('yes','no') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'no',  `cart_discount_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `other_price` float NOT NULL DEFAULT '0',  `created_at` datetime DEFAULT NULL,  `updated_at` datetime DEFAULT NULL,  `extra` longtext COLLATE utf8mb4_unicode_520_ci,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_wdr_order_item_discounts` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_wdr_order_item_discounts` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
