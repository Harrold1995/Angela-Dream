CREATE TABLE `jrg_grp_google_review` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `google_place_id` bigint(20) unsigned NOT NULL,  `rating` int(11) NOT NULL,  `text` varchar(10000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `time` int(11) NOT NULL,  `language` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `author_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `author_url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `profile_photo_url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `hide` varchar(1) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',  PRIMARY KEY (`id`),  KEY `grp_google_place_id` (`google_place_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_grp_google_review` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_grp_google_review` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
