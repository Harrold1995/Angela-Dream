CREATE TABLE `jrg_adtribes_my_conversions` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `conversion_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `project_hash` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `utm_source` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `utm_campaign` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `utm_medium` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `utm_term` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `productId` int(128) NOT NULL,  `orderId` int(128) NOT NULL,  UNIQUE KEY `id` (`id`),  UNIQUE KEY `orderId` (`orderId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_adtribes_my_conversions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_adtribes_my_conversions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
