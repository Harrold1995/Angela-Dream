CREATE TABLE `jrg_rank_math_redirections` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `sources` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,  `url_to` text COLLATE utf8mb4_unicode_520_ci NOT NULL,  `header_code` smallint(4) unsigned NOT NULL,  `hits` bigint(20) unsigned NOT NULL DEFAULT '0',  `status` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `last_accessed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`id`),  KEY `status` (`status`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_rank_math_redirections` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `jrg_rank_math_redirections` VALUES('1', 'a:1:{i:0;a:3:{s:6:\"ignore\";s:0:\"\";s:7:\"pattern\";s:18:\"eyebrow-extentions\";s:10:\"comparison\";s:5:\"exact\";}}', 'http://angelsdreamatelier.com/eyebrow-extensions', '301', '418', 'active', '2021-06-07 07:35:02', '2021-06-07 07:35:02', '2022-04-16 08:39:07');
/*!40000 ALTER TABLE `jrg_rank_math_redirections` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
