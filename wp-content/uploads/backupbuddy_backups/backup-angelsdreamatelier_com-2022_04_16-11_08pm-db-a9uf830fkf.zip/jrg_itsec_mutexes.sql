CREATE TABLE `jrg_itsec_mutexes` (  `mutex_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `mutex_name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `mutex_expires` int(11) unsigned NOT NULL,  PRIMARY KEY (`mutex_id`),  UNIQUE KEY `mutex_name` (`mutex_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_itsec_mutexes` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_itsec_mutexes` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
