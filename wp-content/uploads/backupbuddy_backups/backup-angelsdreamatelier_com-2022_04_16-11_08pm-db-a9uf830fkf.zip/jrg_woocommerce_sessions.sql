CREATE TABLE `jrg_woocommerce_sessions` (  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,  `session_expiry` bigint(20) unsigned NOT NULL,  PRIMARY KEY (`session_id`),  UNIQUE KEY `session_key` (`session_key`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_woocommerce_sessions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_woocommerce_sessions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
