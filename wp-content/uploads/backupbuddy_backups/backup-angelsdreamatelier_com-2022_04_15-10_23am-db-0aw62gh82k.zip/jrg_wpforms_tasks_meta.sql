CREATE TABLE `jrg_wpforms_tasks_meta` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,  `date` datetime NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_wpforms_tasks_meta` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `jrg_wpforms_tasks_meta` VALUES('1', 'wpforms_process_entry_emails_meta_cleanup', 'Wzg2NDAwXQ==', '2020-03-12 00:16:07');
/*!40000 ALTER TABLE `jrg_wpforms_tasks_meta` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
