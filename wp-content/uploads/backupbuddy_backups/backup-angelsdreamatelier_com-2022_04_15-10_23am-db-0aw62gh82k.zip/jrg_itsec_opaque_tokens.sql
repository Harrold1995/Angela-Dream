CREATE TABLE `jrg_itsec_opaque_tokens` (  `token_id` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `token_hashed` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `token_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `token_data` text COLLATE utf8mb4_unicode_520_ci NOT NULL,  `token_created_at` datetime NOT NULL,  PRIMARY KEY (`token_id`),  UNIQUE KEY `token_hashed` (`token_hashed`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_itsec_opaque_tokens` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_itsec_opaque_tokens` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
