CREATE TABLE `jrg_wc_download_log` (  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `timestamp` datetime NOT NULL,  `permission_id` bigint(20) unsigned NOT NULL,  `user_id` bigint(20) unsigned DEFAULT NULL,  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',  PRIMARY KEY (`download_log_id`),  KEY `permission_id` (`permission_id`),  KEY `timestamp` (`timestamp`),  CONSTRAINT `fk_jrg_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `jrg_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_wc_download_log` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_wc_download_log` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
