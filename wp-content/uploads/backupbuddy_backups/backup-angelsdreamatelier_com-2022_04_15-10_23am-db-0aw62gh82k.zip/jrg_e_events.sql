CREATE TABLE `jrg_e_events` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `event_data` text COLLATE utf8mb4_unicode_520_ci,  `created_at` datetime NOT NULL,  PRIMARY KEY (`id`),  KEY `created_at_index` (`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_e_events` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_e_events` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
