CREATE TABLE `jrg_rank_math_analytics_gsc` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  `query` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `page` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `clicks` mediumint(6) NOT NULL,  `impressions` mediumint(6) NOT NULL,  `position` double NOT NULL,  `ctr` double NOT NULL,  PRIMARY KEY (`id`),  KEY `analytics_query` (`query`(191)),  KEY `analytics_page` (`page`(191)),  KEY `clicks` (`clicks`),  KEY `position` (`position`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_rank_math_analytics_gsc` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_rank_math_analytics_gsc` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
