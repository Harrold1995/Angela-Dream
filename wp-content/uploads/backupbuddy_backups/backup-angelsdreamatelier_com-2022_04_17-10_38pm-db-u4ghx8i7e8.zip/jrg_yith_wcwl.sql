CREATE TABLE `jrg_yith_wcwl` (  `ID` int(11) NOT NULL AUTO_INCREMENT,  `prod_id` int(11) NOT NULL,  `quantity` int(11) NOT NULL,  `user_id` int(11) DEFAULT NULL,  `wishlist_id` int(11) DEFAULT NULL,  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `position` int(11) DEFAULT '0',  `original_price` decimal(9,3) DEFAULT NULL,  `original_currency` char(3) DEFAULT NULL,  `on_sale` tinyint(4) NOT NULL DEFAULT '0',  PRIMARY KEY (`ID`),  KEY `prod_id` (`prod_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `jrg_yith_wcwl` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `jrg_yith_wcwl` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
