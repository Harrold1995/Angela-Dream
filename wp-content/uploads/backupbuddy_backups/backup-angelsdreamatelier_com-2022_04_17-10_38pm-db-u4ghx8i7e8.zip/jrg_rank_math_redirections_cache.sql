CREATE TABLE `jrg_rank_math_redirections_cache` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `from_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,  `redirection_id` bigint(20) unsigned NOT NULL,  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `object_type` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',  `is_redirected` tinyint(1) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`),  KEY `redirection_id` (`redirection_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `jrg_rank_math_redirections_cache` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `jrg_rank_math_redirections_cache` VALUES('1', 'eyebrow-extentions', '1', '0', 'any', '1');
/*!40000 ALTER TABLE `jrg_rank_math_redirections_cache` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
